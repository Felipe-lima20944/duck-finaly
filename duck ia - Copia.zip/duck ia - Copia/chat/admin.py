from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as AuthUserAdmin
from django.utils.translation import gettext_lazy as _
from .models import (
    User, PerfilUsuario, PersonalidadeIA,
    Conversa, Mensagem
)

# Inlines para facilitar a visualização e edição de dados relacionados
class PerfilUsuarioInline(admin.StackedInline):
    """Permite editar o perfil do usuário diretamente na página do usuário."""
    model = PerfilUsuario
    can_delete = False
    verbose_name = "perfil"
    verbose_name_plural = "perfis"


@admin.register(User)
class CustomUserAdmin(AuthUserAdmin):
    """
    Personaliza a administração do modelo de usuário para incluir
    os campos personalizados e inlines de perfil e assinatura.
    """
    inlines = [PerfilUsuarioInline]

    fieldsets = (
        (None, {"fields": ("username", "password")}),
        (_("Personal info"), {"fields": ("first_name", "last_name", "email")}),
        (
            _("Permissions"),
            {
                "fields": (
                    "is_active",
                    "is_staff",
                    "is_superuser",
                    "groups",
                    "user_permissions",
                ),
            },
        ),
        (_("Important dates"), {"fields": ("last_login", "date_joined")}),
        (
            _("Preferências do usuário"),
            {
                "fields": (
                    "permite_coleta_dados",
                    "tema_escuro",
                    "ultima_atividade",
                ),
            },
        ),
    )

    list_display = (
        'username',
        'email',
        'is_staff',
        'is_active',
        'ultima_atividade',
    )
    list_filter = (
        'is_staff',
        'is_superuser',
        'is_active',
        'groups',
    )
    search_fields = ('username', 'email')
    readonly_fields = ('last_login', 'date_joined', 'ultima_atividade',)



@admin.register(PersonalidadeIA)
class PersonalidadeIAAdmin(admin.ModelAdmin):
    """Personalização do admin para o modelo PersonalidadeIA."""
    list_display = ('nome', 'descricao', 'ativo', 'alinhamento')
    list_filter = ('ativo', 'alinhamento')
    search_fields = ('nome', 'descricao', 'tom', 'prompt_sistema')
    readonly_fields = ('criado_em',)
    fields = (
        'nome', 'descricao', 'prompt_sistema', 'alinhamento', 'tom',
        'foto_ia', 'etica', 'empatia', 'restricoes', 'ativo',
        'criado_em'
    )


@admin.register(Conversa)
class ConversaAdmin(admin.ModelAdmin):
    """Personalização do admin para o modelo Conversa com mensagens inlines."""
    list_display = (
        'titulo',
        'usuario',
        'personalidade',
        'total_mensagens',
        'total_tokens',
        'modificado_em',
        'excluida',
        'compartilhavel', # NOVO: Exibe o status de compartilhamento na lista
    )
    list_filter = (
        'excluida', 
        'compartilhavel', # NOVO: Filtra por conversas compartilháveis
        'criado_em', 
        'modificado_em', 
        'personalidade', 
    )
    search_fields = ('titulo', 'usuario__username')
    readonly_fields = (
        'id', 
        'uuid_compartilhamento', # NOVO: Torna o UUID somente leitura
        'total_mensagens', 
        'total_tokens', 
        'criado_em', 
        'modificado_em', 
        'excluida_em',
    )
    fields = (
        'usuario', 
        'titulo', 
        'personalidade', 
        'temperatura', 
        'excluida',
        'uuid_compartilhamento', # NOVO: Exibe o UUID no formulário
        'compartilhavel', # NOVO: Permite ao admin marcar como compartilhável
    )
    autocomplete_fields = ['usuario', 'personalidade']

@admin.register(Mensagem)
class MensagemAdmin(admin.ModelAdmin):
    """Personalização do admin para o modelo Mensagem."""
    list_display = (
        'conversa',
        'papel',
        'tipo_conteudo',
        'texto_curto',
        'tokens_utilizados',
        'criado_em',
        'feedback',
    )
    list_filter = ('papel', 'tipo_conteudo', 'feedback', 'criado_em')
    search_fields = ('texto', 'conversa__titulo')
    readonly_fields = ('id', 'tokens_utilizados', 'custo_estimado', 'criado_em', 'feedback')
    autocomplete_fields = ['conversa', 'parent_mensagem']

    @admin.display(description='Texto')
    def texto_curto(self, obj):
        """Exibe um resumo do texto da mensagem."""
        return obj.texto[:75] + '...' if len(obj.texto or '') > 75 else obj.texto


