from django.db import models
import uuid
from django.conf import settings
from django.contrib.auth.models import AbstractUser
from django.utils import timezone
from django.core.validators import MinValueValidator, MaxValueValidator


class User(AbstractUser):
    """
    Modelo de usuário personalizado. Mantém a compatibilidade com o sistema de autenticação
    do Django. Dados de perfil mais detalhados são armazenados em um modelo separado.
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    # Resolvendo o conflito de relacionamento com a aplicação 'auth'
    groups = models.ManyToManyField(
        'auth.Group',
        verbose_name='groups',
        blank=True,
        help_text='The groups this user belongs to. A user will get all permissions '
                  'granted to each of their groups.',
        related_name="chat_user_set",
        related_query_name="user",
    )
    user_permissions = models.ManyToManyField(
        'auth.Permission',
        verbose_name='user permissions',
        blank=True,
        help_text='Specific permissions for this user.',
        related_name="chat_user_permissions_set",
        related_query_name="user",
    )

    permite_coleta_dados = models.BooleanField(
        default=True,
        help_text="Se o usuário permite que suas conversas sejam usadas para melhorar o modelo."
    )

    tema_escuro = models.BooleanField(
        default=False,
        help_text="Se o usuário prefere o tema escuro na interface."
    )

    ultima_atividade = models.DateTimeField(
        auto_now=True,
        help_text="Data e hora da última atividade do usuário."
    )

    class Meta:
        verbose_name = "usuário"
        verbose_name_plural = "usuários"

    def __str__(self):
        return self.username


class PerfilUsuario(models.Model):
    """
    Modelo complementar ao usuário para dados de perfil mais específicos,
    como foto e informações pessoais.
    """
    usuario = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='perfil',
        help_text="O usuário associado a este perfil."
    )
    bio = models.TextField(
        blank=True,
        help_text="Uma breve biografia sobre o usuário."
    )
    foto_perfil = models.ImageField(
        upload_to='profile_pics/',
        blank=True,
        null=True,
        help_text="Foto de perfil do usuário."
    )
    data_aniversario = models.DateField(
        blank=True,
        null=True,
        help_text="Data de aniversário do usuário."
    )

    class Meta:
        verbose_name = "perfil do usuário"
        verbose_name_plural = "perfis dos usuários"

    def __str__(self):
        return f"Perfil de {self.usuario.username}"


class PreferenciasUsuario(models.Model):
    """
    Modelo para armazenar preferências personalizadas do usuário,
    tanto globais quanto específicas por conversa.
    """
    usuario = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='preferencias',
        help_text="Usuário dono das preferências."
    )

    # Preferências globais
    notificacoes_email = models.BooleanField(
        default=True,
        help_text="Se o usuário deseja receber notificações por email."
    )

    notificacoes_push = models.BooleanField(
        default=True,
        help_text="Se o usuário deseja receber notificações push."
    )

    idioma_interface = models.CharField(
        max_length=10,
        default='pt-br',
        help_text="Idioma preferido para a interface (ex: 'pt-br', 'en')."
    )

    tema_padrao = models.CharField(
        max_length=20,
        default='light',
        choices=[
            ('light', 'Claro'),
            ('dark', 'Escuro'),
            ('auto', 'Automático'),
        ],
        help_text="Tema padrão da interface."
    )

    # Preferências de chat
    mostrar_timestamps = models.BooleanField(
        default=True,
        help_text="Se deve mostrar timestamps nas mensagens."
    )

    compactar_mensagens = models.BooleanField(
        default=False,
        help_text="Se deve compactar mensagens antigas."
    )

    auto_scroll = models.BooleanField(
        default=True,
        help_text="Se deve rolar automaticamente para novas mensagens."
    )

    # Preferências de IA
    temperatura_padrao = models.FloatField(
        default=0.7,
        validators=[MinValueValidator(0.0), MaxValueValidator(2.0)],
        help_text="Temperatura padrão para geração de respostas."
    )

    personalidade_favorita = models.ForeignKey(
        'PersonalidadeIA',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        help_text="Personalidade favorita do usuário."
    )

    # Privacidade
    permitir_analytics = models.BooleanField(
        default=True,
        help_text="Se permite coleta de dados analíticos anônimos."
    )

    permitir_treinamento = models.BooleanField(
        default=True,
        help_text="Se permite uso das conversas para treinamento."
    )

    criado_em = models.DateTimeField(auto_now_add=True)
    atualizado_em = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "preferência do usuário"
        verbose_name_plural = "preferências dos usuários"

    def __str__(self):
        return f"Preferências de {self.usuario.username}"


class PersonalidadeIA(models.Model):
    """
    Modelo para definir diferentes personalidades que a IA pode assumir.
    Adicionado campo para foto ou avatar da personalidade.
    """
    nome = models.CharField(
        max_length=50,
        unique=True,
        help_text="Nome identificador da personalidade (ex: 'assistente', 'criativo')."
    )

    descricao = models.CharField(
        max_length=255,
        help_text="Descrição breve da personalidade e seu comportamento."
    )

    prompt_sistema = models.TextField(
        help_text="Instrução do sistema para guiar a personalidade da IA. Ex: 'Você é um assistente prestativo...'"
    )

    alinhamento = models.CharField(
        max_length=50,
        help_text="Alinhamento comportamental da IA (ex: 'ALINHADO', 'NEUTRO_MAL')."
    )

    tom = models.TextField(
        help_text="Tom de voz e estilo da IA (ex: 'Positivo, Ajudante, Empático')."
    )

    foto_ia = models.ImageField(
        upload_to='ai_personalities/',
        blank=True,
        null=True,
        help_text="Foto ou avatar da personalidade da IA."
    )

    etica = models.FloatField(
        validators=[MinValueValidator(0.0), MaxValueValidator(1.0)],
        help_text="Nível de ética da IA (0.0 = sem ética, 1.0 = totalmente ético)."
    )

    empatia = models.FloatField(
        validators=[MinValueValidator(0.0), MaxValueValidator(1.0)],
        help_text="Nível de empatia da IA (0.0 = sem empatia, 1.0 = totalmente empático)."
    )

    restricoes = models.TextField(
        help_text="Restrições e regras comportamentais específicas."
    )

    ativo = models.BooleanField(
        default=True,
        help_text="Se esta personalidade está disponível para uso."
    )

    criado_em = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "personalidade IA"
        verbose_name_plural = "personalidades IA"
        ordering = ['nome']

    def __str__(self):
        return self.nome



class Conversa(models.Model):
    """
    Representa uma única conversa de chat com metadados completos.
    """
    id = models.UUIDField(
        primary_key=True,
        default=uuid.uuid4,
        editable=False,
        help_text="Identificador único da conversa."
    )

    titulo = models.CharField(
        max_length=255,
        default="Nova Conversa",
        help_text="Título da conversa para exibição na interface."
    )

    usuario = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='conversas',
        help_text="O usuário proprietário desta conversa."
    )

    session_id = models.CharField(
        max_length=40,
        null=True,
        blank=True,
        help_text="ID da sessão para usuários anônimos."
    )

    personalidade = models.ForeignKey(
        'PersonalidadeIA',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='conversas',
        help_text="A personalidade da IA usada nesta conversa."
    )

    personalidade_inicial = models.ForeignKey(
        'PersonalidadeIA',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='conversas_iniciais',
        help_text="A personalidade da IA que iniciou a conversa."
    )

    temperatura = models.FloatField(
        default=0.7,
        validators=[MinValueValidator(0.0), MaxValueValidator(2.0)],
        help_text="Valor de temperatura usado para a geração de respostas (0.0 a 2.0)."
    )

    total_mensagens = models.IntegerField(
        default=0,
        help_text="Número total de mensagens nesta conversa."
    )

    total_tokens = models.PositiveIntegerField(
        default=0,
        help_text="Número total de tokens utilizados nesta conversa."
    )

    criado_em = models.DateTimeField(
        auto_now_add=True,
        help_text="Data e hora em que a conversa foi criada."
    )

    modificado_em = models.DateTimeField(
        auto_now=True,
        help_text="Data e hora da última atualização da conversa."
    )

    excluida = models.BooleanField(
        default=False,
        help_text="Indica se a conversa foi excluída (soft delete)."
    )

    excluida_em = models.DateTimeField(
        null=True,
        blank=True,
        help_text="Data e hora em que a conversa foi marcada como excluída."
    )

    # NOVO CAMPO: UUID para compartilhar a conversa de forma segura.
    uuid_compartilhamento = models.UUIDField(
        default=uuid.uuid4, 
        editable=False, 
        unique=True,
        help_text="Identificador único e não adivinhavel para links de compartilhamento."
    )

    # NOVO CAMPO: Indica se a conversa pode ser visualizada publicamente via link.
    compartilhavel = models.BooleanField(
        default=False,
        help_text="Se a conversa pode ser acessada através de um link de compartilhamento público."
    )

    # Novas funcionalidades para plataforma avançada
    prioridade = models.CharField(
        max_length=10,
        choices=[
            ('low', 'Baixa'),
            ('normal', 'Normal'),
            ('high', 'Alta'),
            ('urgent', 'Urgente'),
        ],
        default='normal',
        help_text="Prioridade da conversa para organização."
    )

    categoria = models.CharField(
        max_length=50,
        blank=True,
        help_text="Categoria da conversa (ex: 'trabalho', 'pessoal', 'suporte')."
    )

    tags = models.JSONField(
        default=list,
        blank=True,
        help_text="Lista de tags associadas à conversa em formato JSON."
    )

    # Métricas de qualidade
    satisfacao_media = models.FloatField(
        null=True,
        blank=True,
        validators=[MinValueValidator(0.0), MaxValueValidator(5.0)],
        help_text="Satisfação média das mensagens da conversa (0-5)."
    )

    tempo_medio_resposta = models.DurationField(
        null=True,
        blank=True,
        help_text="Tempo médio de resposta da IA nesta conversa."
    )

    # Configurações específicas da conversa
    configuracoes_personalizadas = models.JSONField(
        default=dict,
        blank=True,
        help_text="Configurações específicas desta conversa (ex: parâmetros customizados)."
    )

    # Estatísticas
    visualizacoes_compartilhamento = models.PositiveIntegerField(
        default=0,
        help_text="Número de visualizações quando compartilhada."
    )

    ultima_interacao = models.DateTimeField(
        null=True,
        blank=True,
        help_text="Última interação do usuário nesta conversa."
    )

    cancelled = models.BooleanField(
        default=False,
        help_text="Indica se a geração de resposta foi cancelada pelo usuário."
    )

    class Meta:
        verbose_name = "conversa"
        verbose_name_plural = "conversas"
        ordering = ['-modificado_em']
        indexes = [
            models.Index(fields=['usuario', 'modificado_em']),
            models.Index(fields=['excluida', 'modificado_em']),
            models.Index(fields=['uuid_compartilhamento']), # Adicione um índice para buscas rápidas
        ]

    def __str__(self):
        return self.titulo or f"Conversa {self.id}"

    def delete(self, using=None, keep_parents=False):
        """Implementação de soft delete."""
        self.excluida = True
        self.excluida_em = timezone.now()
        self.save()

    def restaurar(self):
        """Restaura uma conversa excluída."""
        self.excluida = False
        self.excluida_em = None
        self.save()


class Mensagem(models.Model):
    """
    Representa uma única mensagem dentro de uma conversa.
    """
    ROLES = [
        ('user', 'Usuário'),
        ('assistant', 'Assistente'),
        ('system', 'Sistema'),
        ('tool', 'Ferramenta'),
    ]

    TIPOS_CONTEUDO = [
        ('text', 'Texto'),
        ('image', 'Imagem'),
        ('file', 'Arquivo'),
    ]

    id = models.UUIDField(
        primary_key=True,
        default=uuid.uuid4,
        editable=False,
        help_text="Identificador único da mensagem."
    )

    conversa = models.ForeignKey(
        'Conversa',
        on_delete=models.CASCADE,
        related_name='mensagens',
        help_text="A conversa à qual esta mensagem pertence."
    )

    parent_mensagem = models.ForeignKey(
        'self',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='respostas_alternativas',
        help_text="Mensagem 'pai' para respostas alternativas."
    )

    papel = models.CharField(
        max_length=10,
        choices=ROLES,
        help_text="O papel de quem enviou a mensagem (user, assistant ou system)."
    )

    tipo_conteudo = models.CharField(
        max_length=10,
        choices=TIPOS_CONTEUDO,
        default='text',
        help_text="Tipo de conteúdo da mensagem (ex: 'text', 'image')."
    )

    texto = models.TextField(
        help_text="O conteúdo da mensagem.",
        null=True,
        blank=True
    )

    dados_conteudo = models.FileField(
        upload_to='chat_uploads/',
        help_text="O arquivo associado a esta mensagem, se houver.",
        null=True,
        blank=True
    )

    tokens_utilizados = models.PositiveIntegerField(
        default=0,
        help_text="Número de tokens utilizados por esta mensagem."
    )

    custo_estimado = models.DecimalField(
        max_digits=10,
        decimal_places=6,
        default=0.0,
        help_text="Custo estimado desta mensagem (em dólares)."
    )

    criado_em = models.DateTimeField(
        auto_now_add=True,
        help_text="Data e hora em que a mensagem foi criada."
    )

    metadados = models.JSONField(
        default=dict,
        blank=True,
        help_text="Metadados adicionais em formato JSON."
    )

    feedback = models.BooleanField(
        null=True,
        blank=True,
        help_text="Feedback do usuário sobre a mensagem (True = positivo, False = negativo)."
    )

    # Novas avaliações mais detalhadas
    avaliacao_estrelas = models.PositiveSmallIntegerField(
        null=True,
        blank=True,
        validators=[MinValueValidator(1), MaxValueValidator(5)],
        help_text="Avaliação em estrelas (1-5) da qualidade da resposta da IA."
    )

    reacao_usuario = models.CharField(
        max_length=50,
        blank=True,
        help_text="Reação do usuário (ex: '👍', '👎', '❤️', '😂')."
    )

    # Status da mensagem
    STATUS_CHOICES = [
        ('sent', 'Enviada'),
        ('delivered', 'Entregue'),
        ('read', 'Lida'),
        ('failed', 'Falhou'),
    ]
    status = models.CharField(
        max_length=10,
        choices=STATUS_CHOICES,
        default='sent',
        help_text="Status da entrega da mensagem."
    )

    # Tempos de resposta
    tempo_resposta_ia = models.DurationField(
        null=True,
        blank=True,
        help_text="Tempo que a IA levou para gerar a resposta."
    )

    # Flags para moderação
    sinalizada = models.BooleanField(
        default=False,
        help_text="Se a mensagem foi sinalizada para moderação."
    )

    motivo_sinalizacao = models.TextField(
        blank=True,
        help_text="Motivo pelo qual a mensagem foi sinalizada."
    )

    # Histórico de edições
    editada_em = models.DateTimeField(
        null=True,
        blank=True,
        help_text="Última vez que a mensagem foi editada."
    )

    versao_anterior = models.TextField(
        blank=True,
        help_text="Versão anterior do texto da mensagem (para auditoria)."
    )

    feedback_comentario = models.TextField(
        blank=True,
        help_text="Comentário adicional do usuário sobre o feedback."
    )

    # Soft delete
    excluida = models.BooleanField(
        default=False,
        help_text="Indica se a mensagem foi excluída (soft delete)."
    )

    excluida_em = models.DateTimeField(
        null=True,
        blank=True,
        help_text="Data e hora em que a mensagem foi excluída."
    )

    ordem = models.PositiveIntegerField(
        default=0,
        help_text="Ordem da mensagem dentro da conversa."
    )

    class Meta:
        verbose_name = "mensagem"
        verbose_name_plural = "mensagens"
        ordering = ['ordem']
        indexes = [
            models.Index(fields=['conversa', 'ordem']),
            models.Index(fields=['papel', 'criado_em']),
        ]

    def __str__(self):
        if self.tipo_conteudo == 'text' and self.texto:
            return f"{self.get_papel_display()}: {self.texto[:50]}..."
        elif self.dados_conteudo:
            return f"{self.get_papel_display()}: {self.tipo_conteudo} ({self.dados_conteudo.name})"
        return f"{self.get_papel_display()}: Sem conteúdo"


class AvaliacaoMensagem(models.Model):
    """
    Modelo para avaliações detalhadas das mensagens da IA.
    Permite múltiplas dimensões de avaliação.
    """
    mensagem = models.OneToOneField(
        Mensagem,
        on_delete=models.CASCADE,
        related_name='avaliacao_detalhada',
        help_text="A mensagem sendo avaliada."
    )

    usuario = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        help_text="Usuário que fez a avaliação."
    )

    # Avaliações por dimensão
    qualidade_resposta = models.PositiveSmallIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)],
        help_text="Qualidade da resposta (1-5)."
    )

    relevancia = models.PositiveSmallIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)],
        help_text="Relevância da resposta (1-5)."
    )

    clareza = models.PositiveSmallIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)],
        help_text="Clareza da resposta (1-5)."
    )

    utilidade = models.PositiveSmallIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)],
        help_text="Utilidade da resposta (1-5)."
    )

    comentario = models.TextField(
        blank=True,
        help_text="Comentário detalhado sobre a avaliação."
    )

    criado_em = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "avaliação de mensagem"
        verbose_name_plural = "avaliações de mensagens"
        unique_together = ['mensagem', 'usuario']

    def __str__(self):
        return f"Avaliação de {self.mensagem} por {self.usuario.username}"