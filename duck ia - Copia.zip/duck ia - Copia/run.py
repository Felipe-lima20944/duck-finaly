#!/usr/bin/env python
"""
Script para executar o Dark Duck Intelligence com pyngrok.
Este script inicia o servidor Django e cria um túnel ngrok usando a biblioteca pyngrok.
"""

import os
import sys
import subprocess
import time
import signal
import atexit
from pathlib import Path

# Configurações do ngrok
NGROK_AUTH_TOKEN = "2SGYY0H3kHKVP3aDtC0zFgRmTUV_5MBkhknN2G6eVzAJhgEQB"

# Adicionar o diretório do projeto ao Python path
BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))

try:
    from pyngrok import ngrok
    PYNGROK_AVAILABLE = True
except ImportError:
    PYNGROK_AVAILABLE = False

def check_pyngrok():
    """Verifica se o pyngrok está instalado e configura autenticação."""
    if not PYNGROK_AVAILABLE:
        print("✗ Pyngrok não está instalado.")
        print("Para instalar: pip install pyngrok")
        return False

    print("✓ Pyngrok encontrado!")

    # Verificar se já tem authtoken configurado
    try:
        # Tentar uma operação que requer autenticação
        ngrok.api_request("https://api.ngrok.com/endpoints", method="GET")
        print("✓ Authtoken ngrok já configurado!")
        return True
    except Exception:
        print("⚠️  Authtoken ngrok não configurado.")
        return setup_ngrok_auth()

def setup_ngrok_auth():
    """Configura a autenticação do ngrok."""
    global NGROK_AUTH_TOKEN

    if NGROK_AUTH_TOKEN:
        try:
            ngrok.set_auth_token(NGROK_AUTH_TOKEN)
            print("✅ Authtoken configurado com sucesso!")
            return True
        except Exception as e:
            print(f"❌ Erro ao configurar authtoken: {e}")
            return False
    else:
        print("\n🔑 Configuração do ngrok:")
        print("1. Acesse: https://dashboard.ngrok.com/signup")
        print("2. Crie uma conta gratuita")
        print("3. Vá para: https://dashboard.ngrok.com/get-started/your-authtoken")
        print("4. Copie seu authtoken")

        authtoken = input("\nDigite seu authtoken do ngrok: ").strip()

        if not authtoken:
            print("❌ Authtoken vazio. Tente novamente.")
            return False

        try:
            ngrok.set_auth_token(authtoken)
            NGROK_AUTH_TOKEN = authtoken  # Salvar para futuras execuções
            print("✅ Authtoken configurado com sucesso!")
            return True
        except Exception as e:
            print(f"❌ Erro ao configurar authtoken: {e}")
            return False

def start_django():
    """Inicia o servidor Django."""
    print("🚀 Iniciando servidor Django...")
    os.chdir(BASE_DIR)
    return subprocess.Popen([
        sys.executable, 'manage.py', 'runserver', '0.0.0.0:8000'
    ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)

def start_ngrok_tunnel():
    """Cria túnel ngrok usando pyngrok."""
    print("🌐 Criando túnel ngrok...")
    try:
        # Criar túnel HTTP na porta 8000
        tunnel = ngrok.connect(8000, "http")
        print(f"🎉 Seu app está disponível em: {tunnel.public_url}")
        return tunnel
    except Exception as e:
        print(f"❌ Erro ao criar túnel ngrok: {e}")
        return None

def cleanup(processes, tunnel=None):
    """Encerra os processos e túnel."""
    print("\n🛑 Encerrando processos...")
    if tunnel:
        try:
            ngrok.disconnect(tunnel.public_url)
            print("✓ Túnel ngrok desconectado")
        except:
            pass

    for proc in processes:
        if proc and proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()

def main():
    print("🐥 Dark Duck Intelligence - Inicialização com pyngrok")
    print("=" * 50)

    # Verificar pyngrok
    if not check_pyngrok():
        print("\nInstale o pyngrok com: pip install pyngrok")
        sys.exit(1)

    processes = []
    tunnel = None

    try:
        # Iniciar Django
        django_proc = start_django()
        processes.append(django_proc)

        # Aguardar Django iniciar
        time.sleep(3)

        # Criar túnel ngrok
        tunnel = start_ngrok_tunnel()
        if not tunnel:
            print("❌ Falha ao criar túnel ngrok")
            sys.exit(1)

        print("\n📋 Instruções:")
        print("- Acesse a URL acima para usar o app")
        print("- Pressione Ctrl+C para parar")
        print("\n🔄 Mantendo servidores rodando...")

        # Manter rodando
        while True:
            time.sleep(1)

    except KeyboardInterrupt:
        print("\n⏹️  Interrupção detectada.")
    except Exception as e:
        print(f"\n❌ Erro: {e}")
    finally:
        cleanup(processes, tunnel)
        print("✅ Finalizado!")

if __name__ == '__main__':
    main()